from django.db import models
from django.contrib.auth.models import AbstractUser


class User(AbstractUser):
    GENDER_CHOICES = (
        ('M', 'Male'),
        ('F', 'Female'),
    )

    address = models.TextField(blank=True , null=True)
    age = models.PositiveSmallIntegerField(blank=True , null=True)
    description = models.TextField(blank=True , null=True)
    email = models.EmailField(blank=True , null=True)
    first_name = models.CharField(max_length=50 , blank=True , null=True)
    gender = models.CharField(choices=GENDER_CHOICES, max_length=1 , blank=True , null=True)

    last_login = models.DateTimeField(blank=True, null=True)
    last_name = models.CharField(max_length=50 ,blank=True, null=True)
    password = models.CharField(max_length=50 ,)
    phone = models.CharField(max_length=15 , blank=True , null=True)





